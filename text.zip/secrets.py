key1 = 'AC316387e839c7a7e24e68754d65963f84'
key2 = '9fc502f73b8effe11d6bee49faf0db94'

apixu_api_key = '5f0b15d9a6dd414faf855013170408'

contacts = {'My_Cell': "+15038036025",
            'My_Twilio': '19713402410',
            'Hannah': "+15032061559"}

girlfriend_name = 'Hannah'
city = 'Corvallis'